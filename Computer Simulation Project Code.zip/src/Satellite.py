# -*- coding: utf-8 -*-
"""
Created on Wed Apr 13 07:43:01 2022

@author: Dylan
"""
import Body
import numpy as np

class Satellite(object):
    def __init__(self,
                 name,
                 colour,
                 velocity,
                 angle):
        '''initialization to set body values
           name - '''
        self.name = name
        self.colour = colour
        self.mass = 1000
        
        DISTANCE_TO_EARTH_SURFACE = 149.6*10**9 + 12756/2
        self.position = np.array([DISTANCE_TO_EARTH_SURFACE, 0])
        
        x_velocity = np.cos(angle) * velocity
        y_velocity = np.sin(angle) * velocity
        self.velocity = np.array([x_velocity,y_velocity])
        
        self.current_acceleration = np.array([50, 0])
        self.previous_acceleration = np.array([0, 0])
    
    
    def update_position(self, timestep):
        new_position = np.array([0, 0])
        first_part_of_equation = self.position + self.velocity * timestep
        second_part_of_equation = (1/6) * (4 * self.current_acceleration - self.previous_acceleration) * timestep ** 2
        new_position = first_part_of_equation + second_part_of_equation
        self.position = new_position
    
    def update_velocity(self, timestep, new_acceleration):
        new_velocity = np.array([0,0])
        in_brackets = 2 * new_acceleration + 5 * self.current_acceleration - self.previous_acceleration
        new_velocity = self.velocity + (1/6) * in_brackets * timestep
        self.velocity = new_velocity
    
    def calc_KE(self):
        velocity = (self.velocity[0] ** 2 + self.velocity[1] **2) ** 0.5
        KE = 0.5 * self.mass * velocity ** 2
        return KE