Format for input parameters:

For each line, type Body or Simulation first to indicate what object the parameters refer to.

Format for Body(seperated by spaces):
Body body_name body_colour body_mass(kg) body_distance_from_sun(m) body_velocity(m/s) body_angle(radians (should be np.pi/2 unless it is a satellite))

Format for Satellite(seperated by spaces):
Satellite satellite_name satellite_colour satellite_velocity(m/s) satellite_angle(radians)

Format for Simulation(seperated by spaces):
Simulation simulation_timestep(s) simulation_num_of_iterations