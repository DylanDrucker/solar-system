# -*- coding: utf-8 -*-
"""
Created on Wed Apr  6 22:42:47 2022

@author: s2077148
"""

import numpy as np

class Body(object):
    def __init__(self,
                 name,
                 colour,
                 mass,
                 distance_from_sun,
                 velocity,
                 initial_angle):
        '''initialization to set body values
           name - body_name (string). If it is a body, please name it correctly for orbital period check
           colour - colour of body in animation (string (has to be accepted colour))
           mass - body mass in kg (int)
           distance_from_sun - body initial distance from sun in meters (float)
           velocity - initial velocity of body in m/s (float)
           intial_angle - angle at which body is initially moving relative to the x_axis. (float) (Should be np.pi/2 unless Satellite)'''
           
        self.name = name
        self.colour = colour
        self.mass = mass
        self.position = np.array([distance_from_sun, 0])
        
        x_velocity = np.cos(initial_angle) * velocity
        y_velocity = np.sin(initial_angle) * velocity
        self.velocity = np.array([x_velocity,y_velocity])
        
        self.current_acceleration = np.array([0, 0])
        self.previous_acceleration = np.array([0, 0])
    
    
    def update_position(self, timestep):
        '''method which updates the position of the body, given a timestep in seconds'''
        new_position = np.array([0, 0])
        first_part_of_equation = self.position + self.velocity * timestep
        second_part_of_equation = (1/6) * (4 * self.current_acceleration - self.previous_acceleration) * timestep ** 2
        new_position = first_part_of_equation + second_part_of_equation
        self.position = new_position
    
    def update_velocity(self, timestep, new_acceleration):
        '''method which updates the velocity of the body, given a timestep in seconds and a new acceleration in m/s^2'''
        new_velocity = np.array([0,0])
        in_brackets = 2 * new_acceleration + 5 * self.current_acceleration - self.previous_acceleration
        new_velocity = self.velocity + (1/6) * in_brackets * timestep
        self.velocity = new_velocity
    
    def calc_KE(self):
        '''method which calculates and returns the kinetic energy of the body'''
        velocity = (self.velocity[0] ** 2 + self.velocity[1] **2) ** 0.5
        KE = 0.5 * self.mass * velocity ** 2
        return KE
        