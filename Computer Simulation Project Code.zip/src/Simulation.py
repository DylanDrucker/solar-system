# -*- coding: utf-8 -*-
"""
Created on Thu Apr  7 13:59:44 2022

@author: s2077148
"""
import numpy as np
import Body
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation


class Simulation(object):
    def __init__(self,
                 timestep,
                 num_iterations,
                 body_list):
        '''initialization to set simulation values
           timestep - time between updating body values (int)(in seconds) 
           num_iterations - number of times body values will be updated (int)
           body_list - list of bodies to be simulated'''
        self.timestep = timestep
        self.num_iterations = num_iterations
        self.body_list = body_list            
        
        '''body_positions saves body positions over the entire simulation.
        Then, it can be used to animate the simulation given the calculated data'''
        self.body_positions = []
        for body in self.body_list:
            self.body_positions.append([body.position])
            
        self.completed_orbits = dict.fromkeys(self.body_list, 0)    #Dictionary to keep a record of how many orbits each body has completed for orbital period calculation
        
        self.energy_file = open('energy_data.txt', 'w')     #File for writing total energy of system
        self.orbit_file = open('orbit_data.txt', 'w')       #File for writing orbital period data
        

    def run_simulation(self):
        '''method that runs the simulation, calling methods to generate and write data'''
        
        '''calculates acceleration for bodies for the first iteration'''
        for body in self.body_list:
            new_acceleration = self.calc_acceleration(body)
            body.current_acceleration = new_acceleration
            body.previous_acceleration = new_acceleration
        for i in range(self.num_iterations):
            self.step_forward()
            self.write_tot_energy()
            self.write_completed_orbits(i)
            
        self.orbit_file.close()
        self.energy_file.close()
                
    
    def step_forward(self):
        '''method that steps the bodies forward by one timestep, first updating their positions, then their accelerations and velocities'''
        for i in range(len(self.body_list)):
            body = self.body_list[i]
            body.update_position(self.timestep)
            self.body_positions[i].append(body.position)
        for body in self.body_list:
            new_acceleration = self.calc_acceleration(body)
            body.update_velocity(self.timestep,new_acceleration)
            body.previous_acceleration = body.current_acceleration
            body.current_acceleration = new_acceleration
            
            
 
    def calc_acceleration(self, body):
        '''method that calculates the new acceleration of a body with the Beeman Algorithm'''
        
        GRAVITATIONAL_CONSTANT = 6.67408 * 10 ** (-11)
        new_acceleration = np.array([0.0,0.0])
        
        for other_body in self.body_list:
            distance = self.get_distance(body, other_body)
            if distance != 0:   #Ensures other_body != body
                difference = body.position - other_body.position
                equation = other_body.mass / (distance ** 3) * difference
                new_acceleration += equation
        
        new_acceleration = new_acceleration * GRAVITATIONAL_CONSTANT * -1
        return new_acceleration

    
    def calc_PE(self):
        '''method that calculates the Potential Energy of the system'''
        gravitational_constant = 6.67408 * 10 ** (-11)
        total_PE = 0
        for body in self.body_list:
            for other_body in self.body_list:
                distance = self.get_distance(body, other_body)
                if distance != 0:   #Ensures other_body != body
                    equation = gravitational_constant * body.mass * other_body.mass / distance
                    total_PE += equation
        total_PE = total_PE * (-0.5)
        return total_PE
                
    
    def write_tot_energy(self):
        '''method that calculates the total energy based on the KE and PE of the system,
           and writes the informtion to the energy file'''
        total_KE = 0
        for body in self.body_list:
            total_KE += body.calc_KE()
        total_PE = self.calc_PE()
        total_energy = total_KE + total_PE
        
        self.energy_file.write('KE: ' + str(total_KE) + '\n')     
        self.energy_file.write('PE: ' + str(total_PE) + '\n')
        self.energy_file.write('TE: ' + str(total_energy) + '\n')  
        
    def write_completed_orbits(self, current_iteration):
        '''method that checks if a body has completed an orbit, and if so, writes the stats to the orbit file'''
        SECONDS_IN_A_DAY = 86400
        DAYS_IN_A_YEAR = 365.2
        SECONDS_IN_A_YEAR = SECONDS_IN_A_DAY * DAYS_IN_A_YEAR
        EXPECTED_BODY_ORBIT_PERIODS = {'Mercury' : 88.0 / DAYS_IN_A_YEAR, 'Venus' : 224.7 / DAYS_IN_A_YEAR, 'Earth' : 365.2 / DAYS_IN_A_YEAR, 'Mars' : 687 / DAYS_IN_A_YEAR}
        
        completed = []
        for i in range(len(self.body_list)):        #The method checks if an orbit has been completed by seeing if the y value of a body has gone from negative to positive
            curr_y_pos = self.body_positions[i][-1][1]
            prev_y_pos = self.body_positions[i][-2][1]
            if prev_y_pos < 0 and curr_y_pos >= 0:  #If the previous y value was negative, and the current y value is positive, and orbit has been completed
                body =  self.body_list[i]
                completed.append(body)
                self.completed_orbits[body] += 1
        if completed != []:
            for body in completed:  #Calculates orbit period, compares it to expected value, writes this data to file
                num_completed_orbits = self.completed_orbits[body]
                orbit_period = self.timestep * current_iteration / SECONDS_IN_A_YEAR / num_completed_orbits     #Orbit period is given in number of earth years
                expected_orbit_period = EXPECTED_BODY_ORBIT_PERIODS[body.name]
                percent_difference = abs((orbit_period - expected_orbit_period) / expected_orbit_period * 100)
                
                self.orbit_file.write(body.name + ' has completed '+ str(num_completed_orbits) + ' orbit(s). Average Orbital Period: ' + str(orbit_period) + ' Earth years' + '\n')
                self.orbit_file.write('Expected Value: ' + str(expected_orbit_period) + '. Accuracy: ' + str(100 - percent_difference) + '%' + '\n')
                self.orbit_file.write('\n')
    
    def get_distance(self, body, other_body):
        '''helper function for calculating distance between two bodies'''
        distance_x = (body.position[0] - other_body.position[0]) ** 2
        distance_y = (body.position[1] - other_body.position[1]) ** 2
        distance = (distance_x + distance_y) ** 0.5
        return distance

    
    def run_animation(self):
        '''method which, using the data gathered from run_simulation(), animates the simulation'''
        
        '''turn bodies in body_list into patches for plotting in animation'''
        AU = 1.496 * 10**11     #Astronomical unit to set the circle sizes for the patches
        self.patch_list = []
        for body in self.body_list:
            self.patch_list.append(plt.Circle((body.position[0], body.position[1]), 0.10 * AU, color = body.colour, animated = True))
        
        fig = plt.figure()
        ax = plt.axes()
        for patch in self.patch_list:
            ax.add_patch(patch)
        
        ax.axis('scaled')        
        ax.set_xlim(-2 * AU, 2 * AU)
        ax.set_ylim(-2 * AU, 2 * AU)
        
        self.anim = FuncAnimation(fig, self.patch_position, frames = self.num_iterations, repeat = True, interval = 1, blit = True)
        plt.show()
    
    def patch_position(self, i):
        '''helper function that iterates over the body_positions for the animation function'''
        for j in range(len(self.patch_list)):
            (self.patch_list[j]).center = (self.body_positions[j][i][0], self.body_positions[j][i][1])
        return self.patch_list
            
    def plot_tot_energy(self):
        '''method which, using the energy data written in the energy file from run_simulation(), plots the total energy'''
        self.energy_file = open('energy_data.txt', 'r')
        KE = []
        PE = []
        TE = []
        lines = self.energy_file.readlines()
        for line in lines:
            line = line.split()
            if line[0] == 'KE:':
                KE.append(eval(line[1]))
            elif line[0] == 'PE:':
                PE.append(eval(line[1]))
            elif line[0] == 'TE:':
                TE.append(eval(line[1]))
        self.energy_file.close()
        
        seconds = []
        for i in range(len(TE)):
            seconds.append(self.timestep * i)
            
        #plt.plot(seconds, KE, label = 'Kinetic Energy')
        #plt.plot(seconds, PE, label = 'Potential Energy')
        plt.figure()
        plt.plot(seconds, TE, label = 'Total Energy')
        plt.xlabel('Time (seconds)')
        plt.ylabel('Energy (joules)') 
        plt.legend()
        plt.show()
        
        TEmax = 0
        TEmin = float('inf')
        TEmean = 0
        
        for te in TE:
            TEmean += te
        TEmean = TEmean / len(TE)

        print('mean = ' + str(TEmean))
    
        