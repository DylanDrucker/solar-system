# -*- coding: utf-8 -*-
"""
Created on Wed Apr  6 22:05:17 2022

@author: s2077148
"""

import Body
import Simulation
import numpy as np

def get_simulation_from_input_file(filename):
    '''method which, when given input file filename, reads the formatted information
       and returns a simulation object with the desired parameters to then be run by main'''
    body_list = []
    
    input_file = open(filename,'r')
    lines = input_file.readlines()
    for line in lines:
        parameters = line.split()   #Each parameter is ordered and seperated by spaces. (Check READ_ME for more info)
        if parameters[0] == 'Body':
            body_list.append(Body.Body(parameters[1], parameters[2],eval(parameters[3]),eval(parameters[4]),eval(parameters[5]), eval(parameters[6])))
        elif parameters[0] == 'Simulation':
            timestep = eval(parameters[1])
            num_iterations = eval(parameters[2])
    input_file.close()
    
    simulation = Simulation.Simulation(timestep, num_iterations, body_list)
    return simulation
    

def main():
    simulation = get_simulation_from_input_file('input_parameters.txt')
    simulation.run_simulation()
    simulation.run_animation()
    simulation = get_simulation_from_input_file('input_parameters_orbit_&_energy.txt')  #Sorry this one takes a very long time to run. I wanted to be thorough with the energy plot
    simulation.run_simulation()
    simulation.plot_tot_energy()

if __name__ == "__main__":
    main()